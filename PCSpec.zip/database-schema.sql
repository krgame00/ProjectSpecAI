-- ---------------------------------------------------------
-- Smart PC Builder - MySQL Database Schema
-- ---------------------------------------------------------
-- ออกแบบมาเพื่อรองรับการตรวจสอบความเข้ากันได้ทางเทคนิค (Compatibility Check)
-- เช่น Socket ของ CPU กับ Motherboard, ประเภท RAM (DDR4/DDR5), และการคำนวณกำลังไฟ (PSU Wattage)

CREATE DATABASE IF NOT EXISTS smart_pc_builder DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smart_pc_builder;

-- 1. ตารางหมวดหมู่อุปกรณ์ (Hardware Category) - เผื่อการขยายตัวในอนาคต
CREATE TABLE `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `slug` VARCHAR(50) NOT NULL UNIQUE, -- เช่น 'cpu', 'motherboard', 'ram'
  `name_th` VARCHAR(100) NOT NULL,    -- เช่น 'ซีพียู', 'เมนบอร์ด'
  `description` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. ตารางรวมสินค้าทั้งหมด (Products Master) - เก็บข้อมูลพื้นฐานที่ทุกชิ้นต้องมี
CREATE TABLE `products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT NOT NULL,
  `brand` VARCHAR(100) NOT NULL,
  `model` VARCHAR(255) NOT NULL,
  `price` DECIMAL(10, 2) NOT NULL,
  `image_url` VARCHAR(255),
  `stock_quantity` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE CASCADE
);

-- 3. ตารางสเปค CPU
CREATE TABLE `spec_cpu` (
  `product_id` INT PRIMARY KEY,
  `socket` VARCHAR(50) NOT NULL,      -- สำหรับเช็คกับ Motherboard (เช่น LGA1700, AM5)
  `core_count` INT NOT NULL,
  `thread_count` INT NOT NULL,
  `base_clock` DECIMAL(4,2),          -- GHz
  `boost_clock` DECIMAL(4,2),         -- GHz
  `tdp_watt` INT NOT NULL,            -- สำหรับเช็คกับ PSU
  `integrated_graphics` BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
);

-- 4. ตารางสเปค Motherboard
CREATE TABLE `spec_motherboard` (
  `product_id` INT PRIMARY KEY,
  `socket` VARCHAR(50) NOT NULL,      -- เช็คกับ CPU
  `form_factor` VARCHAR(50) NOT NULL, -- เช่น ATX, mATX, Mini-ITX (เช็คกับ Case)
  `ram_type` VARCHAR(20) NOT NULL,    -- เช่น DDR4, DDR5 (เช็คกับ RAM)
  `ram_slots` INT NOT NULL,           -- จำนวนสล็อต RAM
  `max_ram_capacity` INT NOT NULL,    -- GB
  `m2_slots` INT DEFAULT 0,
  `sata_ports` INT DEFAULT 0,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
);

-- 5. ตารางสเปค RAM
CREATE TABLE `spec_ram` (
  `product_id` INT PRIMARY KEY,
  `ram_type` VARCHAR(20) NOT NULL,    -- เช่น DDR4, DDR5 (เช็คกับ Motherboard)
  `capacity_gb` INT NOT NULL,         -- ความจุรวม (เช่น 16)
  `modules` INT NOT NULL,             -- จำนวนแถว (เช่น 2 สำหรับ 2x8GB)
  `speed_mhz` INT NOT NULL,           -- ความเร็ว (เช่น 3200, 5200)
  `cas_latency` INT,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
);

-- 6. ตารางสเปค GPU (การ์ดจอ)
CREATE TABLE `spec_gpu` (
  `product_id` INT PRIMARY KEY,
  `chipset_brand` VARCHAR(50),        -- NVIDIA, AMD, Intel
  `chipset_model` VARCHAR(100),       -- เช่น RTX 4060, RX 7600
  `vram_gb` INT NOT NULL,
  `vram_type` VARCHAR(20),            -- เช่น GDDR6, GDDR6X
  `core_clock` INT,                   -- MHz
  `tdp_watt` INT NOT NULL,            -- สำหรับเช็คกับ PSU
  `length_mm` INT,                    -- (Optional) ไว้แจ้งเตือนขนาดกับ Case
  `recommended_psu_watt` INT,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
);

-- 7. ตารางสเปค Storage (SSD/HDD)
CREATE TABLE `spec_storage` (
  `product_id` INT PRIMARY KEY,
  `type` VARCHAR(50) NOT NULL,        -- เช่น NVMe M.2, SATA SSD, HDD
  `capacity_gb` INT NOT NULL,
  `read_speed_mbps` INT,
  `write_speed_mbps` INT,
  `form_factor` VARCHAR(50),          -- เช่น M.2 2280, 2.5", 3.5"
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
);

-- 8. ตารางสเปค PSU (เพาเวอร์ซัพพลาย)
CREATE TABLE `spec_psu` (
  `product_id` INT PRIMARY KEY,
  `wattage` INT NOT NULL,             -- เช็คกับ (CPU TDP + GPU TDP + อื่นๆ)
  `efficiency_rating` VARCHAR(50),    -- เช่น 80+ Gold, 80+ Bronze
  `form_factor` VARCHAR(50) NOT NULL, -- เช่น ATX, SFX
  `modularity` VARCHAR(50),           -- Full, Semi, Non
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
);

-- 9. ตารางสเปค Case (เคสคอมพิวเตอร์)
CREATE TABLE `spec_case` (
  `product_id` INT PRIMARY KEY,
  `form_factor_support` VARCHAR(255) NOT NULL, -- เช่น 'ATX, mATX, Mini-ITX' (เช็คกับ Motherboard)
  `max_gpu_length_mm` INT,            -- (Optional) ไว้แจ้งเตือนขนาด GPU
  `max_cpu_cooler_height_mm` INT,     -- (Optional)
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
);

-- ---------------------------------------------------------
-- ข้อมูลจำลอง (Seed Data) หมวดหมู่
-- ---------------------------------------------------------
INSERT INTO `categories` (`slug`, `name_th`) VALUES
('cpu', 'ซีพียู (CPU)'),
('motherboard', 'เมนบอร์ด (Motherboard)'),
('ram', 'แรม (RAM)'),
('gpu', 'การ์ดจอ (VGA)'),
('storage', 'ที่เก็บข้อมูล (Storage)'),
('psu', 'พาวเวอร์ซัพพลาย (PSU)'),
('case', 'เคส (Case)');
