const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

// Import Database Connection
const db = require('./config/db');

// Import Routes
const hardwareRoutes = require('./routes/hardware');
const chatbotRoutes = require('./routes/chatbot');
const orderRoutes = require('./routes/orders');
const authRoutes = require('./routes/auth');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// API Routes
app.use('/api/hardware', hardwareRoutes);
app.use('/api/chatbot', chatbotRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/auth', authRoutes);

// Base Route
app.get('/', (req, res) => {
  res.send('Smart PC Builder API is running.');
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
