const express = require('express');
const router = express.Router();
const db = require('../config/db'); // MySQL Connection

// GET /api/hardware/catalog
// ดึงข้อมูลแคตตาล็อกสินค้าทั้งหมด พร้อมสเปคสำหรับเช็คความเข้ากันได้
router.get('/catalog', async (req, res) => {
  try {
    // โค้ดตัวอย่างการดึงข้อมูลและ Join กับตาราง spec ย่อย
    const [products] = await db.query(`
      SELECT p.*, 
             c.socket as cpu_socket, c.tdp_watt as cpu_tdp,
             m.socket as mobo_socket, m.ram_type as mobo_ram_type,
             r.ram_type, r.capacity_gb,
             g.tdp_watt as gpu_tdp, g.length_mm,
             psu.wattage as psu_wattage,
             case_spec.form_factor_support, case_spec.max_gpu_length_mm
      FROM products p
      LEFT JOIN spec_cpu c ON p.id = c.product_id AND p.category_id = 'cpu'
      LEFT JOIN spec_motherboard m ON p.id = m.product_id AND p.category_id = 'mobo'
      LEFT JOIN spec_ram r ON p.id = r.product_id AND p.category_id = 'ram'
      LEFT JOIN spec_gpu g ON p.id = g.product_id AND p.category_id = 'gpu'
      LEFT JOIN spec_psu psu ON p.id = psu.product_id AND p.category_id = 'psu'
      LEFT JOIN spec_case case_spec ON p.id = case_spec.product_id AND p.category_id = 'case'
    `);
    
    // จัดกลุ่มตาม Category เพื่อส่งให้ Vue.js ใช้งานง่ายๆ
    const catalog = { cpu: [], mobo: [], ram: [], gpu: [], storage: [], psu: [], case: [] };
    products.forEach(product => {
      if(catalog[product.category_id]) {
        catalog[product.category_id].push(product);
      }
    });

    res.json(catalog);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Database error' });
  }
});

// GET /api/hardware/:id
// ดึงข้อมูลสินค้าเฉพาะชิ้น
router.get('/:id', async (req, res) => {
  // Logic here
  res.json({ message: `Get product ${req.params.id}` });
});

module.exports = router;
