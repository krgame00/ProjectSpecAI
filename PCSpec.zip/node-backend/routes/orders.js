const express = require('express');
const router = express.Router();
const db = require('../config/db');

// POST /api/orders
// สร้างคำสั่งซื้อใหม่ (Checkout)
router.post('/', async (req, res) => {
  try {
    const { customer_name, customer_address, customer_phone, assembly_type, total_price, build_items } = req.body;

    // 1. ตรวจสอบข้อมูล
    if (!customer_name || !build_items || Object.keys(build_items).length === 0) {
      return res.status(400).json({ error: 'Invalid order data' });
    }

    // 2. บันทึกข้อมูลลงฐานข้อมูล orders
    // const [result] = await db.query('INSERT INTO orders ...');
    const newOrderId = `ORD-${Math.floor(Math.random() * 10000) + 1000}`;

    // 3. บันทึกรายการฮาร์ดแวร์ลงตาราง order_items (วนลูปตาม build_items)

    res.status(201).json({ 
      success: true, 
      order_id: newOrderId,
      message: 'สร้างคำสั่งซื้อสำเร็จ'
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to create order' });
  }
});

// GET /api/orders/:id/status
// ตรวจสอบสถานะคำสั่งซื้อ (ใช้โดย Chatbot หรือหน้า Dashboard)
router.get('/:id/status', async (req, res) => {
  try {
    // const [order] = await db.query('SELECT status FROM orders WHERE order_id = ?', [req.params.id]);
    res.json({ order_id: req.params.id, status: 'assembling' });
  } catch (error) {
    res.status(500).json({ error: 'Database error' });
  }
});

module.exports = router;
