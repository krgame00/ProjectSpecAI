const express = require('express');
const router = express.Router();

// Mock NLP Processing Service (or connect to real LLM API like OpenAI/Gemini)
const processMessageWithNLP = async (message) => {
  const lowerMsg = message.toLowerCase();
  
  if (lowerMsg.includes('แอนิเมชัน') || lowerMsg.includes('3d')) {
    return {
      reply: 'สำหรับงาน 3D และ Animation ผมแนะนำให้ใช้ CPU แบบ Multi-core เช่น Ryzen 9 หรือ Core i7 คู่กับการ์ดจอที่เรนเดอร์ได้ดีอย่าง RTX 4070 SUPER ครับ',
      presets: [{ id: 'anim', label: 'ใช้งานสเปคนี้' }]
    };
  } else if (lowerMsg.includes('wuthering') || lowerMsg.includes('emulator')) {
    return {
      reply: 'สำหรับการเล่น Wuthering Waves พร้อมเปิด Emulator แนะนำ CPU Ryzen 9 และ RTX 4060 ครับ',
      presets: [{ id: 'emu', label: 'ใช้งานสเปคนี้' }]
    };
  } else if (lowerMsg.includes('งบ') || lowerMsg.includes('ถูก')) {
    return {
      reply: 'สำหรับเซ็ตประหยัดงบ ผมแนะนำ i5-13400F คู่กับ DDR4 และ RTX 4060 ครับ คุ้มค่าที่สุดแล้ว',
      presets: [{ id: 'budget', label: 'ใช้งานสเปคนี้' }]
    };
  }

  return {
    reply: 'รับทราบครับ รบกวนแจ้งโปรแกรมหรือเกมที่ใช้งานเป็นหลัก หรือคุณสามารถเลือกจาก Preset ที่ผมเตรียมไว้ให้ได้ครับ',
    presets: [
      { id: 'anim', label: 'สายเรนเดอร์ 3D' },
      { id: 'emu', label: 'ฮาร์ดคอร์เกมเมอร์' }
    ]
  };
};

// POST /api/chatbot/message
// รับข้อความจากผู้ใช้และส่งกลับคำตอบ + presets
router.post('/message', async (req, res) => {
  try {
    const { message } = req.body;
    if (!message) return res.status(400).json({ error: 'Message is required' });

    // ประมวลผลข้อความด้วย AI/NLP
    const response = await processMessageWithNLP(message);

    res.json(response);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

module.exports = router;
